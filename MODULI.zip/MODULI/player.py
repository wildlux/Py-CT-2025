import pygame

class Menu:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.Font(None, 74)
        self.options = ["Start Game", "Quit"]
        self.selected_option = 0
        self.menu_items = []
        self._setup_menu_items()

    def _setup_menu_items(self):
        # Calculate positions for menu items
        y_offset = 200
        for i, option in enumerate(self.options):
            text_surface = self.font.render(option, True, WHITE)
            text_rect = text_surface.get_rect(center=(self.screen.get_width() / 2, y_offset + i * 80))
            self.menu_items.append({"text": text_surface, "rect": text_rect, "action": option.replace(" ", "_").upper()})

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            for item in self.menu_items:
                if item["rect"].collidepoint(event.pos):
                    return item["action"]
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.selected_option = (self.selected_option - 1) % len(self.options)
            elif event.key == pygame.K_DOWN:
                self.selected_option = (self.selected_option + 1) % len(self.options)
            elif event.key == pygame.K_RETURN:
                return self.menu_items[self.selected_option]["action"]
        return None

    def update(self):
        # No complex updates for a simple menu, but could include animations
        pass

    def draw(self):
        self.screen.fill(BLACK) # Or draw a background image
        for i, item in enumerate(self.menu_items):
            color = WHITE
            if i == self.selected_option:
                color = (255, 255, 0) # Highlight selected option
            text_surface = self.font.render(self.options[i], True, color)
            self.screen.blit(text_surface, item["rect"])