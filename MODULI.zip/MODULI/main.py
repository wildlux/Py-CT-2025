import pygame
#from menu import menu
#import Menu.Game
#import level1
from __init__ import  SCREEN_WIDTH ,SCREEN_HEIGHT
from __init__ import SOME_VAR # print (SOME_VAR)
#import player
#import objects
#import Platform, Coin
#from settings import SCREEN_WIDTH, SCREEN_HEIGHT, TITLE

def Quadrato( screen ,color , x, y , LARGHEZZA, ALTEZZA):
    Bordo_Vuoto = True
    pygame.draw.rect(screen, color, x, y, SCREEN_WIDTH, SCREEN_HEIGHT ,Bordo_Vuoto)   

class Game :
    def __init__(self ):
        pygame.init()
        TITLE = "PYgame Catania"
        print ("-" *20 ,"\n| Risoluzione del gioco\n| Larghezza :",SCREEN_WIDTH , "\n| Altezza : ",SCREEN_HEIGHT,"\n" +"-" *20) 
        self.screen = pygame.display.set_mode( (SCREEN_WIDTH, SCREEN_HEIGHT) )
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        self.running = True
        self.current_state = "MENU" # Initial state
        self.color = "red"
        self.Bordo_Vuoto = True
        #self.Quadrato( self.screen, self.color , 10,10 , SCREEN_WIDTH, SCREEN_HEIGHT ,self.Bordo_Vuoto )
    


    def run(self):
        Run = True
        while Run:
            run = False
            #pygame.display.flip()
            self.clock.tick(60) # 60 FPS
        pygame.quit()
    

if __name__ == "__main__":
    game = Game()
    game.run()