import pygame

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50)) # Placeholder image
        self.image.fill((0, 255, 0)) # Green player
        self.rect = self.image.get_rect(midbottom=(400, 500))
        self.speed_x = 0
        self.speed_y = 0
        self.is_jumping = False

    def update(self):
        self.speed_x = 0
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.speed_x = -5
        if keys[pygame.K_RIGHT]:
            self.speed_x = 5
        if keys[pygame.K_SPACE] and not self.is_jumping:
            self.speed_y = -15 # Jump strength
            self.is_jumping = True

        self.rect.x += self.speed_x
        self.rect.y += self.speed_y

        # Apply gravity (simple example)
        self.speed_y += 0.5
        if self.rect.bottom >= 500: # Assuming ground at y=500
            self.rect.bottom = 500
            self.speed_y = 0
            self.is_jumping = False

    def draw(self, screen):
        screen.blit(self.image, self.rect)