import pygame

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill((100, 100, 100)) # Gray platform
        self.rect = self.image.get_rect(topleft=(x, y))

    def draw(self, screen):
        screen.blit(self.image, self.rect)

class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill((255, 255, 0)) # Yellow coin
        self.rect = self.image.get_rect(center=(x, y))
        self.collected = False

    def update(self):
        # Could add spinning animation or similar
        pass

    def draw(self, screen):
        if not self.collected:
            screen.blit(self.image, self.rect)