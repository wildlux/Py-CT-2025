import pygame
#from menu import Menu
#from level1 import Level1
import settings 
import main
class Game:
    def __init__(self,SCREEN_WIDTH,SCREEN_HEIGHT,TITLE):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        self.running = True
        self.current_state = "MENU" # Initial state

        self.menu = Menu(self.screen)
        self.level1 = Level1(self.screen) # Will be initialized or reset when starting level 1

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                # Handle events based on current_state
                if self.current_state == "MENU":
                    self.menu.handle_event(event)
                elif self.current_state == "LEVEL1":
                    self.level1.handle_event(event)

            # Update and draw based on current_state
            if self.current_state == "MENU":
                action = self.menu.update()
                if action == "START_GAME":
                    self.current_state = "LEVEL1"
                    self.level1.reset() # Reset or initialize level 1
                self.menu.draw()
            elif self.current_state == "LEVEL1":
                self.level1.update()
                self.level1.draw()

            pygame.display.flip()
            self.clock.tick(60) # 60 FPS

        pygame.quit()

