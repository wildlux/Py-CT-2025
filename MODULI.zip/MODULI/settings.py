import pygame
from settings import SCREEN_WIDTH, SCREEN_HEIGHT
TITLE = "miogioco"
class Level1:
    def __init__(self, screen):
        self.screen = screen
        self.player = Player()
        self.all_sprites = pygame.sprite.Group()
        self.platforms = pygame.sprite.Group()
        self.coins = pygame.sprite.Group()
        self.setup_level()

    def setup_level(self):
        # Add player to all_sprites group
        self.all_sprites.add(self.player)

        # Create platforms
        platform1 = Platform(0, SCREEN_HEIGHT - 40, SCREEN_WIDTH, 40)
        platform2 = Platform(200, 350, 150, 20)
        self.platforms.add(platform1, platform2)
        self.all_sprites.add(platform1, platform2)

        # Create coins
        coin1 = Coin(100, 400)
        coin2 = Coin(300, 300)
        self.coins.add(coin1, coin2)
        self.all_sprites.add(coin1, coin2)

    def reset(self):
        # Reset player position, clear collected coins, etc.
        self.player = Player()
        self.all_sprites.empty()
        self.platforms.empty()
        self.coins.empty()
        self.setup_level()

    def handle_event(self, event):
        # Level-specific event handling if any, e.g., pause menu key
        pass

    def update(self):
        self.all_sprites.update()

        # Player-platform collision (simple example)
        for platform in self.platforms:
            if self.player.rect.colliderect(platform.rect):
                if self.player.speed_y > 0 and self.player.rect.bottom <= platform.rect.top + self.player.speed_y:
                    self.player.rect.bottom = platform.rect.top
                    self.player.speed_y = 0
                    self.player.is_jumping = False

        # Player-coin collision
        collected_coins = pygame.sprite.spritecollide(self.player, self.coins, True)
        for coin in collected_coins:
            print("Coin collected!") # You'd update score here

        # Level completion conditions, etc.

    def draw(self):
        self.screen.fill((135, 206, 235)) # Sky blue background
        self.all_sprites.draw(self.screen) # Draws all sprites in the group